<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "db";  // Nome del database

// Connessione al database
$connessione = new mysqli($servername, $username, $password, $db);

if ($connessione->connect_error) {
    die("Connessione fallita: " . $connessione->connect_error);
}

// Variabili per raccogliere i dati dal form
$id = $nome = $email = "";

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Raccogli i dati dal form
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];

    // Query per inserire i dati nella tabella Automobile
    $sql1 = "INSERT INTO utente (id, nome, email) VALUES ('$id', '$nome', '$email');";
    
    if ($connessione->query($sql1) === TRUE) {
        echo "<h1>Registrazione completata!</h1>";
    } else {
        echo "Errore: " . $connessione->error;
    }

    // Chiudi la connessione
    $connessione->close();
}
?>
<form action="aa.php">
    <button type="submit">guarda</button>
</form><br>

</body>
</html>
