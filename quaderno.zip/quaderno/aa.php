<html>
<body>
<?php
$host = "localhost";        
$username = "root";         
$password = "";         
$dbname = "db";  // Nome del database

// Connessione al database
$connessione = new mysqli($host, $username, $password, $dbname);

if ($connessione->connect_error) {
    die("Connessione fallita: " . $connessione->connect_error);
}

// Esegui la query per recuperare i dati dalla tabella Utente
$risultati = $connessione->query("SELECT * FROM Utente");

echo "<h2>Elenco Utenti</h2><table border='1'><tr><th>ID</th><th>Nome</th><th>Email</th></tr>";

while ($row = $risultati->fetch_assoc()) {
    echo "<tr><td>" . $row['id'] . "</td><td>" . $row['nome'] . "</td><td>" . $row['email'] . "</td></tr>";
}

echo "</table>";


?>
<br>



<form action="index.html">
    <button type="submit">Torna indietro</button>
</form><br>

</body>
</html>
